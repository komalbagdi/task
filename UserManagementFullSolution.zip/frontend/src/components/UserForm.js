
import React, { useEffect, useState } from 'react';

export default function UserForm() {
  const [users, setUsers] = useState([]);
  const [form, setForm] = useState({ name: '', email: '', password: '', dob: '' });

  useEffect(() => {
    fetch('http://localhost:8000/api/user/read.php')
      .then(res => res.json())
      .then(data => setUsers(data));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    await fetch('http://localhost:8000/api/user/create.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    });
    window.location.reload();
  };

  return (
    <div>
      <h2>Add User</h2>
      <form onSubmit={handleSubmit}>
        <input placeholder="Name" onChange={e => setForm({ ...form, name: e.target.value })} /><br />
        <input placeholder="Email" onChange={e => setForm({ ...form, email: e.target.value })} /><br />
        <input placeholder="Password" type="password" onChange={e => setForm({ ...form, password: e.target.value })} /><br />
        <input placeholder="DOB" type="date" onChange={e => setForm({ ...form, dob: e.target.value })} /><br />
        <button type="submit">Add</button>
      </form>
      <h2>User List</h2>
      <ul>
        {users.map(user => <li key={user.id}>{user.name} ({user.email})</li>)}
      </ul>
    </div>
  );
}
