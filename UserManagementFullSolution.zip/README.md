
# User Management System

## 🔧 Backend (PHP)

- Located in `backend/`
- RESTful API: `create`, `read`, `update`, `delete` users

## 🌐 Frontend (React)

- Located in `frontend/`
- Form to add user and list to view users

## 🧰 Setup Instructions

### 📂 1. Backend

- Import `schema.sql` in MySQL
- Start PHP server:

```bash
cd backend
php -S localhost:8000
```

### ⚛️ 2. Frontend

```bash
cd frontend
npm install
npm start
```

Then visit `http://localhost:3000`

### ✅ Version Control

- Use Git: `git init`, `git add .`, `git commit -m "initial"`, `git push`

---

Built with ❤️ using PHP + React
