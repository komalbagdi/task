<?php
include_once '../../config/database.php';
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"));

if (!empty($data->name) && !empty($data->email) && !empty($data->password)) {
    $database = new Database();
    $db = $database->getConnection();

    $query = "INSERT INTO users SET name=:name, email=:email, password=:password, dob=:dob";
    $stmt = $db->prepare($query);

    $stmt->bindParam(":name", $data->name);
    $stmt->bindParam(":email", $data->email);
    $stmt->bindParam(":password", password_hash($data->password, PASSWORD_DEFAULT));
    $stmt->bindParam(":dob", $data->dob);

    echo json_encode(["success" => $stmt->execute()]);
} else {
    echo json_encode(["success" => false, "message" => "Incomplete data."]);
}
?>
